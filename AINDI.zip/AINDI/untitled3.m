G1 = [1 2 3 4; 5 6 7 8];
G2 = [1 2 3 4; 5 6 7 8];
save('GMatrix.mat',G1, 'G1');
save('GMatrix.mat', G2);